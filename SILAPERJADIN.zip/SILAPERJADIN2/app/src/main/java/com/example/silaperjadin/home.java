package com.example.silaperjadin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class home extends AppCompatActivity {
   // CalendarView calv;
    Button upload, logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // calv = (CalendarView) findViewById(R.id.jadwal);
        //LoadJadwalSPD();
        upload = (Button)  findViewById(R.id.buttonUpload);
        logout = (Button) findViewById(R.id.buttonLogout);
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Silahkan Buat laporan",
                        Toast.LENGTH_SHORT).show();
                OpenInputReportActivity();
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //setContentView(R.layout.activity_login);
                Toast.makeText(getApplicationContext(), "Load jadwal",
                        Toast.LENGTH_SHORT).show();
                LoadJadwalSPD();
            }
        });

    }
    public void OpenInputReportActivity(){
        Intent intent2 = new Intent(this, InputReport.class);
        startActivity(intent2);
    }
    public void LoadJadwalSPD() {
        TableLayout tablelayoutid = (TableLayout) this.findViewById(R.id.TableLayoutTugas);

        // Inflate your row "template" and fill out the fields.
        TableRow row = (TableRow) getLayoutInflater().inflate(R.layout.addmainrowlayout, null);
        for (int i = 1; i < 10; i++) {

            ((TextView) row.findViewById(R.id.rowNo)).setText(i);
            ((TextView) row.findViewById(R.id.rowKeg)).setText("Peta");
            ((TextView) row.findViewById(R.id.rowTanggal)).setText("10 Mei");
            ((TextView) row.findViewById(R.id.rowAct)).setText("icon");
            tablelayoutid.addView(row);
        }
    }
}
