package com.example.silaperjadin;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
public static final String DATABASE = "SiRanDiLocal.db";
public static final int DATABASE_VERSION = 1;
    public DatabaseHelper(Context context){
        super(context, DATABASE, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        String sqlCreate = "create table ReportInsert(RepId integer primary key, RepCont text null, UploadStatus boolean null);";//Syntax create table
        Log.d("Data","OnCreate : "+sqlCreate);
        db.execSQL(sqlCreate);
    }

    @Override
    public void onUpgrade (SQLiteDatabase Args0, int Args1, int Args2){

    }
}
