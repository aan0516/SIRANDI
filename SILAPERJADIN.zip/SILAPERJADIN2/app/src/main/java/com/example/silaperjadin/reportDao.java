package com.example.silaperjadin;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface reportDao {
    @Query("SELECT * FROM reportRoom")
    List<reportRoom> getAll();

    //Custom Query
    @Query("SELECT * FROM reportRoom WHERE flag = 0")
    reportRoom findByName (String flag);
    @Insert
        /* void insertAll (reportRoom insert); */
    void insertAll(String currentTime, String report);
    @Delete
    void deleteUser (reportRoom delete);


}
