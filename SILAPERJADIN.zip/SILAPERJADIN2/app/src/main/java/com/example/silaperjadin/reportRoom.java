package com.example.silaperjadin;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class reportRoom {
@PrimaryKey (autoGenerate = true)
    int id;
@ColumnInfo (name = "idkeg")
    String idkeg;
@ColumnInfo (name = "waktu")
    String waktu;
@ColumnInfo (name = "detailKeg")
    String detailKeg;
@ColumnInfo(name = "flag")
    String flag;

public int getId(){
    return id;
    }
    public void setId(int id){
        this.id = id;
    }

    public String getIdkeg() {
        return idkeg;
    }

    public void setIdkeg(String idkeg) {
        this.idkeg = idkeg;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getDetailKeg() {
        return detailKeg;
    }

    public void setDetailKeg(String detailKeg) {
        this.detailKeg = detailKeg;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
