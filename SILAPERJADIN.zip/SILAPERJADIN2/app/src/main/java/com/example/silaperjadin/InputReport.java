package com.example.silaperjadin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class InputReport extends AppCompatActivity {
    protected Cursor cursor;
    DatabaseHelper dbHelper;
    Button sent;
    EditText inputReportText;
    IntentFilter intentFilter;
    TextView tv;
    insertDb db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_report);
      //  dbHelper = new DatabaseHelper(this);
        inputReportText = (EditText) findViewById(R.id.EditTextdetailActivity);
        sent = (Button) findViewById(R.id.buttonSent);
        db = Room.databaseBuilder(getApplicationContext(), insertDb.class,
                "sirandilocal").allowMainThreadQueries().build();
        sent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String Report = inputReportText.getText().toString();
            Send(Report);


            switch (v.getId()){
                case R.id.buttonSent:
                    showSoftKeyboard(v);
                    break;
            }

               // SQLiteDatabase db = dbHelper.getWritableDatabase();
             //   db.execSQL("insert into ReportInsert(no , id_user , nama, time_start,laporan , upl_state) values('" +
              //          );
            }
        });

    }
    //public insertDb getDb{
      //  return db;
    //}
    public void showSoftKeyboard(View view) {
        if (view.requestFocus()) {
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getApplicationWindowToken(),0);
        }
    }

    private void Send (String Report) {
       String currentTime = new SimpleDateFormat("kk:mm", Locale.getDefault()).format(new Date());
       TableLayout tablelayoutid = (TableLayout)this.findViewById(R.id.TableLayoutInsert);
       // Inflate your row "template" and fill out the fields.
       TableRow row = (TableRow)getLayoutInflater().inflate(R.layout.addrowlayout, null);
       ((TextView)row.findViewById(R.id.rowTime)).setText(currentTime);
       ((TextView)row.findViewById(R.id.rowDetails)).setText(Report);
       tablelayoutid.addView(row);
       inputReportText.setText(null);

       db.userDao.insertAll(currentTime,Report);
    }
  //  @Override
    //protected void onResume() {
        //register the receiver
     //   registerReceiver(intentReceiver, intentFilter);
       // super.onResume();
    //}

   // @Override
    //protected void onPause() {
        //unregister the receiver
      //  unregisterReceiver(intentReceiver);
        //super.onPause();
    //}
}
